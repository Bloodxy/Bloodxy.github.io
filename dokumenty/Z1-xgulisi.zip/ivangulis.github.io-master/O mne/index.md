---
layout: default
title: "Niečo o mne"
obrazok: "/obrazky/cestovanie/eifelovka.jpg"
---
# {{ page.title }}

<img src="{{ site.url }}{{ page.obrazok }}" alt="Moja fotka">

Volám sa Ivan Gulis. Mám 22 rokov a som z Bratislavy. Moja online prezývka je Bloody (alebo Bloodxy).
Študujem na Slovenskej technickej univerzite, fakulta informatiky a informačných technológii, 6. semester.
Mám jedného mladšieho brata Martina, ktorý je teraz v 4. semestri na STU. Je šikovnší a múdrejší ako ja.

Som silný introvert žijúci hlavne vo virtuálnom svete, vášnivý počítačový hráč.
Vyrastal som na strategických hrách ako napr. série Age of Empires a Warcraft.
Ako fanúšik Warcraftu som pár rokov strávil aj vo svete World of Warcraft, najväčšej MMORPG hre.
V súčasnosti ma bavia multiplayer battle arény, ako Dota 2 a League of Legends.
Na informatiku som sa dal už na základnej škole, kde som sa chcel hrať na počítači, a čo najmenej komunikovať s ľudmi v reálnom svete.

Nie som komunikatívny typ, ale som priateľský, trpezlivý, zodpovedný a rád sa učím nové veci. Mám rád zmeny.
Dá sa povedať, že som trochu asociál.
Vždy mi išla matematika, a účastnil som sa všetkých matematických olympiád a pytagoriád. 

Čo sa hudby týka, mám rád rock, metal a nightcore. 
Vyrastal som na nu-metal/rock skupine Linkin Park, a postupne prešiel na metal Disturbed.
V súčasnosti počúvam Nightcore, upravený rock a metal do rýchlejšieho tempa vo vyššej tónine.
Hral som chvíľu na bubny, ale dlho som nevydržal a bubny predal.

Mám rád jedlo, hlavne mäso, a rád varím. Zjem prakticky všetko jedlé.

Milujem psy aj mačky ale mám fóbiu z hadov.
Vo voľnom čase čítam japonskú mangu (komix), kde mám prečítaných cez 40 máng, čo tvorí pár desiatok tisíc strán.
Čítam hlavne epické ságy s veľa postavami a ich backstory. Tiež by v nich malo byť násilie a akcia.
Mojou obľúbenou mangou je Berserk, potom Claymore a Elfen Lied.
Kupodivu nerád čítam knihy - chýbajú mi tam obrázky.
Tiež pozerám japonské anime, ktoré je na spomenutých mangách založené.
Z filmov mám rád sci-fi o super hrdinoch (DC aj Marvel) a hlavne horrory.