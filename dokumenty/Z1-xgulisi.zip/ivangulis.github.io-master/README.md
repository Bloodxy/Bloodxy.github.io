Ak by náhodou jekyll hlásil chyby s encodingom (po nejakom editovaní súboru), zmažte všetko v žložke _site, 
jekyll si to znova pregeneruje a všetko funguje v poriadku.

Stránka bola testovaná na prehliadači google chrome.

Plugin je použitý v zložke Záujmy a hobby, kde sú vložené youtube videá k Hudba, PC hry, Manga a Anime.
Dátové typy sú použité v postoch Cestovanie a v jednotlivých študijných predmetoch.
