---
layout: default
title: "Životopis"
pdf: "/dokumenty/zivotopis.pdf"
---

# {{ page.title }}

Stiahnuteľná verzia: [(stiahnuť PDF)]({{ site.url }}{{ page.pdf }})

**Osobné údaje**

|---|--:|
| Meno a priezvisko | Ivan Gulis |
| Adresa | Mierová 28 821 05 Bratislava |
| Telefón | 0948976571 |
| E-mail | gulis2505@gmail.com |
| Dátum narodenia | 25.05.1993 |

**Vzdelanie**

|---|
| 2009 - 2013 Gymnázium Ladislava Novomeského | 
| Tomášiková 2, Bratislava |
| Odbor: Informatika |
|   |
| 2013+ Slovenská technická univerzita |
| Ilkovičova 2, Bratislava |
| Odbor: Informatika |
| Fakulta informatika a informačných technológii |

**Schopnosti a znalosti**

|---|--:|
| Internet (e-mail, www) | bežný používateľ |
| Microsoft Word | bežný používateľ |
| Microsoft Excel | bežný používateľ |
| Java | mierne pokročilý |
| C | mierne pokročilý |
| SQL | mierne pokročilý |
| C# | základy |
| C++ | základy |

**Jazykové znalosti**

|---|--:|
| Slovenský jazyk | materinský jazyk |
| Anglický jazyk | mierne pokročilý |

**Vodičský preukaz**

|---|--:|
| Skupina | B |

**Záujmy a záľuby**

|---|
| filmy, počítačové hry, varenie |
