---
layout: post
title: "Manga a Anime"
title1: "Berserk"
title2: "Claymore"
title3: "Elfen Lied"
date: 2016-03-11
tag: "ZAUJEM"
alt1: "berserk"
alt2: "claymore"
alt33: "elfenLied"
obrazok1: "/obrazky/zaujmy/mangaAAnime/berserk.jpg"
obrazok2: "/obrazky/zaujmy/mangaAAnime/claymore.jpg"
obrazok3: "/obrazky/zaujmy/mangaAAnime/elfenLied.jpg"
zdroj1: "https://i.ytimg.com/vi/w1o4O2SfQ5g/maxresdefault.jpg"
zdroj2: "https://shanee.io/images/blog/anime/claymore/claymore.jpg"
zdroj3: "http://orig12.deviantart.net/347c/f/2012/021/a/9/elfen_lied_banner_by_klipox-d4n4xp1.png"
opis1: "Berserk je mojou najoblúbenejšou mangou, a jeho animovaná reprezentácia je tiež fascinujúca. Má cez 8000 strán, a prvý diel vyšiel pred 25 rokmi. Príbeh sa odohráva v stredoveku, kde sa hlavný hrdina Guts pripojí do žoldnierskej družiny. Je tu extrémne veľa násilia, a backstory postáv je neskutočne poprepletané."
opis2: "Claymore je príbehom čarodejníc, ktoré si vedia požičat silu démonov na boj so samotnými démonmi. Hlavnou hrdinkou je najslabšia čarodejnica Claire, ktorá má v sebe najsilnejšieho démona - jej priateľku. Naozaj skvelí príbeh a akcia. Anime adaptácia je trochu kratšia, ale oplatí sa pozrieť."
opis3: "Elfen Lied rozpráva príbeh Dicloniusov - ľudí, ktorý majú chromozóm naviac, a dokázu ovládať neviditeľné ruky pripnuté na chbrte. Lucy, hlavná hrdinka, utečie z ústavu pre držanie dicloniusov, a chce sa všetkým pomstiť. Krv a násilie tu je na dennom poriadku, keďže neviditeľné ruky môžu byť ostré ako britvy."
---

## Zopár mojich obľúbených videí k vyššie spomenutým anime *(zľava Berserk, Claymore, Elfen Lied)*:

{% youtube iLMimcmxIdk %} {% youtube -eoZuF88quo %} {% youtube qtwYcHNNw6U %}